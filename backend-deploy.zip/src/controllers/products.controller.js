/**
 * Controller del catalogo — Fan Portal
 * GET /api/products?page=0&limit=6
 */
const { listProducts } = require('../services/catalog.service');

function list(req, res) {
  const page = Math.max(0, parseInt(req.query.page, 10) || 0);
  const limit = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 6));
  // La URL base se arma con la direccion que uso el cliente (sirve en el PC y en el celular)
  // PUBLIC_URL (opcional) fija la direccion publica, p. ej. https://api.midominio.cl
  const baseUrl = (process.env.PUBLIC_URL || `${req.protocol}://${req.get('host')}`).replace(/\/$/, '');

  try {
    res.status(200).json(listProducts({ page, limit, baseUrl }));
  } catch (error) {
    console.error(`[Catalogo] ${error.message}`);
    res.status(500).json({ error: 'No se pudo leer el catalogo. Revisa backend/data/catalog.json (npm run catalog:check).' });
  }
}

module.exports = { list };
