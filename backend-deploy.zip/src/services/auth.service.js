/**
 * Autenticacion — Fan Portal (PC-01 / Paso 01 del flujo: emision de JWT)
 * Los socios viven en data/members.json con la contrasena hasheada (scrypt).
 * Esto es la version previa a PostgreSQL: la tabla members ocupara el lugar del archivo.
 */
const fs = require('fs');
const path = require('path');
const { sign } = require('../utils/jwt');
const { verifyPassword } = require('../utils/password');

const MEMBERS_FILE = path.join(__dirname, '..', '..', 'data', 'members.json');
const MAX_FAILS = 5;
const WINDOW_MS = 60 * 1000;
const fails = new Map(); // rut limpio -> { count, resetAt }

const cleanRut = (v = '') => String(v).replace(/[^0-9kK]/g, '').toUpperCase();

class AuthError extends Error {
  constructor(message, status = 401) {
    super(message);
    this.status = status;
  }
}

function isBlocked(key) {
  const f = fails.get(key);
  if (!f) return false;
  if (Date.now() > f.resetAt) {
    fails.delete(key);
    return false;
  }
  return f.count >= MAX_FAILS;
}

function registerFail(key) {
  const f = fails.get(key);
  if (!f || Date.now() > f.resetAt) fails.set(key, { count: 1, resetAt: Date.now() + WINDOW_MS });
  else f.count += 1;
}

function login(rut, password) {
  const key = cleanRut(rut);
  if (!key || !password) throw new AuthError('Ingresa RUT y contraseña.', 400);
  if (isBlocked(key)) throw new AuthError('Demasiados intentos. Espera un minuto e intenta de nuevo.', 429);

  const members = JSON.parse(fs.readFileSync(MEMBERS_FILE, 'utf8'));
  const member = members.find((m) => cleanRut(m.rut) === key);

  if (!member || !verifyPassword(password, member.passwordHash)) {
    registerFail(key);
    throw new AuthError('RUT o contraseña incorrectos.');
  }
  fails.delete(key);

  const role = member.role || 'socio';
  const token = sign({ sub: key, name: member.name, role });
  return {
    token,
    user: { rut: member.rut, name: member.name, memberType: member.memberType, discountRate: member.discountRate, role },
  };
}

module.exports = { login, AuthError };
