/**
 * Servicio de catalogo — Fan Portal
 * Lee backend/data/catalog.json EN CADA PETICION: para cambiar precios, stock o fotos
 * basta editar ese archivo y guardar; no hace falta reiniciar el servidor.
 */
const fs = require('fs');
const path = require('path');

const CATALOG_FILE = path.join(__dirname, '..', '..', 'data', 'catalog.json');
const IMAGES_DIR = path.join(__dirname, '..', '..', 'public', 'products');

function readCatalog() {
  const parsed = JSON.parse(fs.readFileSync(CATALOG_FILE, 'utf8'));
  if (!Array.isArray(parsed)) throw new Error('catalog.json debe contener una lista de productos [ ... ].');
  return parsed;
}

/** Devuelve la URL publica de la foto, o null si no hay foto o el archivo no existe. */
function resolveImage(image, baseUrl) {
  if (!image || typeof image !== 'string') return null;
  if (/^https?:\/\//i.test(image)) return image; // enlace externo
  const file = path.basename(image);
  if (!fs.existsSync(path.join(IMAGES_DIR, file))) return null;
  return `${baseUrl}/static/products/${encodeURIComponent(file)}`;
}

function normalize(p, baseUrl) {
  const price = Number(p.price);
  const stock = Number(p.stock);
  if (!p.id || !p.name || !Number.isFinite(price) || price < 0 || !Number.isFinite(stock)) {
    console.warn(`[Catalogo] Producto omitido por datos invalidos: ${JSON.stringify(p)}`);
    return null;
  }
  return {
    id: String(p.id),
    name: String(p.name),
    price: Math.round(price),
    stock: Math.max(0, Math.floor(stock)),
    emoji: p.emoji || '🛍️',
    image: resolveImage(p.image, baseUrl),
  };
}

/** Lista paginada de productos activos (active: false los oculta). */
function listProducts({ page = 0, limit = 6, baseUrl }) {
  const all = readCatalog()
    .filter((p) => p.active !== false)
    .map((p) => normalize(p, baseUrl))
    .filter(Boolean);
  const start = page * limit;
  return { items: all.slice(start, start + limit), hasMore: start + limit < all.length, total: all.length };
}

// ---------------------------------------------------------------------------
// ESCRITURA (solo la usan las rutas de administracion, protegidas por token)
// ---------------------------------------------------------------------------
class CatalogError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

const MAX_IMAGE_BYTES = 3 * 1024 * 1024;

function writeCatalog(list) {
  const tmp = `${CATALOG_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(list, null, 2) + '\n', 'utf8');
  fs.renameSync(tmp, CATALOG_FILE); // reemplazo atomico: nunca queda un archivo a medias
}

/** Valida y limpia los campos editables. En modo parcial solo revisa los que llegan. */
function cleanFields(input = {}, { partial }) {
  const out = {};
  if (!partial || input.name !== undefined) {
    const name = String(input.name ?? '').trim();
    if (!name || name.length > 80) throw new CatalogError('El nombre es obligatorio (máximo 80 caracteres).');
    out.name = name;
  }
  if (!partial || input.price !== undefined) {
    const price = Number(input.price);
    if (!Number.isInteger(price) || price < 0 || price > 10000000) throw new CatalogError('El precio debe ser un número entero entre 0 y 10.000.000.');
    out.price = price;
  }
  if (!partial || input.stock !== undefined) {
    const stock = Number(input.stock);
    if (!Number.isInteger(stock) || stock < 0 || stock > 100000) throw new CatalogError('El stock debe ser un número entero entre 0 y 100.000.');
    out.stock = stock;
  }
  if (input.emoji !== undefined) {
    const emoji = String(input.emoji).trim();
    if (emoji.length > 8) throw new CatalogError('El ícono es demasiado largo.');
    out.emoji = emoji || '🛍️';
  }
  if (input.active !== undefined) {
    if (typeof input.active !== 'boolean') throw new CatalogError('"active" debe ser verdadero o falso.');
    out.active = input.active;
  }
  return out;
}

function toAdminView(p, baseUrl) {
  return {
    id: String(p.id),
    name: String(p.name),
    price: Number(p.price),
    stock: Number(p.stock),
    emoji: p.emoji || '🛍️',
    active: p.active !== false,
    image: resolveImage(p.image, baseUrl),
  };
}

/** Lista COMPLETA para el panel (incluye los ocultos). */
function listAllForAdmin(baseUrl) {
  return readCatalog().map((p) => toAdminView(p, baseUrl));
}

function nextId(list) {
  const max = list.reduce((m, p) => {
    const n = /^P(\d+)$/.exec(String(p.id));
    return n ? Math.max(m, Number(n[1])) : m;
  }, 0);
  return `P${String(max + 1).padStart(3, '0')}`;
}

function createProduct(input, baseUrl) {
  const list = readCatalog();
  const fields = cleanFields(input, { partial: false });
  const product = { id: nextId(list), image: '', emoji: '🛍️', active: true, ...fields };
  list.push(product);
  writeCatalog(list);
  return toAdminView(product, baseUrl);
}

function updateProduct(id, input, baseUrl) {
  const list = readCatalog();
  const product = list.find((p) => String(p.id) === String(id));
  if (!product) throw new CatalogError('Producto no encontrado.', 404);
  Object.assign(product, cleanFields(input, { partial: true }));
  writeCatalog(list);
  return toAdminView(product, baseUrl);
}

/** Detecta el tipo real de imagen por sus primeros bytes (no confia en lo que declare el cliente). */
function detectImageExt(buf) {
  if (buf.length > 12 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.length > 12 && buf.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buf.length > 12 && buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return 'webp';
  return null;
}

function saveProductImage(id, base64, baseUrl) {
  if (!/^[A-Za-z0-9_-]+$/.test(String(id))) throw new CatalogError('Identificador no válido.');
  if (typeof base64 !== 'string' || !base64) throw new CatalogError('No llegó ninguna imagen.');
  const buf = Buffer.from(base64.replace(/^data:[^;]+;base64,/, ''), 'base64');
  if (buf.length > MAX_IMAGE_BYTES) throw new CatalogError('La imagen pesa más de 3 MB. Usa una más liviana.', 413);
  const ext = detectImageExt(buf);
  if (!ext) throw new CatalogError('Formato no permitido. Usa una imagen JPG, PNG o WEBP.');

  const list = readCatalog();
  const product = list.find((p) => String(p.id) === String(id));
  if (!product) throw new CatalogError('Producto no encontrado.', 404);

  fs.mkdirSync(IMAGES_DIR, { recursive: true });
  const filename = `${id}-${Date.now()}.${ext}`; // nombre nuevo cada vez: evita fotos viejas en cache
  fs.writeFileSync(path.join(IMAGES_DIR, filename), buf);

  // Borra la foto anterior solo si la habia subido este panel (empieza con "<id>-")
  const old = product.image && !/^https?:\/\//i.test(product.image) ? path.basename(product.image) : null;
  if (old && old.startsWith(`${id}-`) && old !== filename) {
    try {
      fs.unlinkSync(path.join(IMAGES_DIR, old));
    } catch (e) {
      /* si ya no existe, no importa */
    }
  }

  product.image = filename;
  writeCatalog(list);
  return toAdminView(product, baseUrl);
}

module.exports = {
  listProducts,
  readCatalog,
  listAllForAdmin,
  createProduct,
  updateProduct,
  saveProductImage,
  CatalogError,
  CATALOG_FILE,
  IMAGES_DIR,
};
